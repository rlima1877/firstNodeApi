var app = require('./config/app_config');
var db = require('./config/db_config');
var Product = require('./models/product');
var productController = require('./controllers/productController');
var products = require('./routes/productRouter');

app.get('/', function(req,res){

	res.end('Welcome to Products API');
});

app.use('/products', products);