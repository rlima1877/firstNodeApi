var Product = require('../models/product');

exports.save = function(name, description, price, callback){
	new Product({
		'name' : name,
		'description' : description,
		'price' : price
	}).save(function(error, product){
		if(error){
			callback({
				error: 'Unable to save'});
		}else{
			callback(product);
		}
	});
}

exports.list = function(callback){
	Product.find({}, function(error, product){
		if(error){
			callback({error: 'Unable to find product'});
		}else{
			callback(product);
		}
	});
}

exports.delete = function(id, callback){
	Product.findById(id, function(error, product){
		if(error){
			callback({error: 'Unable to delete'});
		}else{
			product.remove(function(error){
				if(!error){
					callback({response: "product excluded successfully"});
				}
			})
		}
	});
}


