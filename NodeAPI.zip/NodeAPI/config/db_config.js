var mongoose = require('mongoose');

var urlString = 'mongodb://localhost/API';

mongoose.connect(urlString, function(err, res){
	if(err){
		console.log('Unable to connect to: ' + urlString);
	}else{
		console.log('Connected to : ' + urlString);
	}
});